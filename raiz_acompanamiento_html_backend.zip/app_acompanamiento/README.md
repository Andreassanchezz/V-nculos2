# Raíz — aplicación de acompañamiento socioeducativo

Este proyecto contiene un prototipo funcional de frontend + backend.

## Estructura

- `public/index.html` — interfaz.
- `public/styles.css` — diseño pastel responsive.
- `public/app.js` — navegación y funciones del prototipo.
- `src/server.js` — backend Express con sesiones, roles y API.
- `package.json` — dependencias y comandos.

## Ejecutar en ordenador

Necesitas Node.js.

```bash
npm install
npm start
```

Después abre `http://localhost:3000`.

## Usuarios de demo

- Joven: `joven@demo.local` / `demo1234`
- Educador: `educador@demo.local` / `demo1234`
- Administrador: `admin@demo.local` / `demo1234`

## Importante antes de producción

Las contraseñas incluidas son SOLO para demo. Para una aplicación real hay que sustituirlas por un proveedor de autenticación seguro (Google OAuth + correo/contraseña), almacenar las contraseñas con hash, usar HTTPS, base de datos persistente, almacenamiento privado para documentos, control de acceso a nivel de servidor, auditoría, copias de seguridad y una política de protección de datos adecuada.

La alerta de emergencia del prototipo registra el aviso en el backend. Para notificaciones reales en iOS/Android habría que integrar APNs/FCM y configurar permisos y notificaciones críticas según las posibilidades del sistema operativo.

La parte de "Google" del botón de inicio está preparada como punto de integración, pero no contiene credenciales OAuth reales.
