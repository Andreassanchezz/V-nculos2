const express=require("express");
const path=require("path");
const crypto=require("crypto");
const app=express();
const PORT=process.env.PORT||3000;
app.use(express.json({limit:"10mb"}));
app.use(express.static(path.join(__dirname,"../public")));

const users=[
 {id:"u1",email:"joven@demo.local",password:"demo1234",name:"Lucía",role:"joven",centerId:"c1"},
 {id:"u2",email:"educador@demo.local",password:"demo1234",name:"María · Educadora",role:"educador",centerId:"c1"},
 {id:"u3",email:"admin@demo.local",password:"demo1234",name:"Administrador",role:"admin",centerId:"c1"}
];
const sessions=new Map();
const diaries=new Map([["u1",{content:"Hoy he organizado mis papeles y he ido a clase.",createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()}]]);
const emergencies=[];
const notes=[];

function safeUser(u){const {password,...x}=u;return x}
function auth(req,res,next){
 const sid=req.headers["x-session-id"];
 const uid=sessions.get(sid);
 if(!uid)return res.status(401).json({error:"No autenticado"});
 const u=users.find(x=>x.id===uid);
 if(!u)return res.status(401).json({error:"Sesión inválida"});
 req.user=u;next();
}
function canSeeUser(req,targetId){
 if(req.user.role==="admin"||req.user.role==="educador")return true;
 return req.user.id===targetId;
}

app.post("/api/auth/login",(req,res)=>{
 const {email,password}=req.body||{};
 const u=users.find(x=>x.email===email&&x.password===password);
 if(!u)return res.status(401).json({error:"Correo o contraseña incorrectos"});
 const sid=crypto.randomUUID();sessions.set(sid,u.id);
 res.json({sessionId:sid,user:safeUser(u)});
});
app.post("/api/auth/logout",auth,(req,res)=>{
 const sid=req.headers["x-session-id"];sessions.delete(sid);res.json({ok:true});
});
app.get("/api/auth/me",(req,res)=>{
 const sid=req.headers["x-session-id"],uid=sessions.get(sid),u=users.find(x=>x.id===uid);
 if(!u)return res.json({user:null});res.json({user:safeUser(u)});
});
app.get("/api/diary",auth,(req,res)=>{
 const d=diaries.get(req.user.id)||null;res.json({entry:d});
});
app.post("/api/diary",auth,(req,res)=>{
 if(req.user.role!=="joven")return res.status(403).json({error:"Solo el joven puede editar su diario"});
 const content=String(req.body?.content||"");
 const old=diaries.get(req.user.id);
 const now=new Date().toISOString();
 diaries.set(req.user.id,{content,createdAt:old?.createdAt||now,updatedAt:now});
 res.json({ok:true,entry:diaries.get(req.user.id)});
});
app.get("/api/young-people",auth,(req,res)=>{
 if(req.user.role==="joven")return res.status(403).json({error:"Acceso restringido"});
 res.json({users:users.filter(u=>u.centerId===req.user.centerId).map(safeUser)});
});
app.get("/api/young-people/:id/diary",auth,(req,res)=>{
 if(!canSeeUser(req,req.params.id))return res.status(403).json({error:"Sin permiso"});
 res.json({entry:diaries.get(req.params.id)||null});
});
app.post("/api/notes",auth,(req,res)=>{
 if(req.user.role==="joven")return res.status(403).json({error:"Sin permiso"});
 const note={id:crypto.randomUUID(),from:req.user.id,to:req.body.to,content:String(req.body.content||""),createdAt:new Date().toISOString()};
 notes.push(note);res.json({ok:true,note});
});
app.post("/api/emergency",auth,(req,res)=>{
 const allowed=["leve","importante","grave"];if(!allowed.includes(req.body.level))return res.status(400).json({error:"Nivel inválido"});
 const e={id:crypto.randomUUID(),userId:req.user.id,user:req.user.name,level:req.body.level,createdAt:new Date().toISOString()};
 emergencies.push(e);
 console.log("EMERGENCIA:",e);
 res.status(201).json({ok:true,emergency:e});
});
app.get("/api/emergencies",auth,(req,res)=>{
 if(req.user.role==="joven")return res.status(403).json({error:"Sin permiso"});
 res.json({emergencies});
});
app.get("/api/health",(req,res)=>res.json({ok:true,service:"raiz-backend"}));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"../public/index.html")));
app.listen(PORT,()=>console.log(`Raíz funcionando en http://localhost:${PORT}`));
