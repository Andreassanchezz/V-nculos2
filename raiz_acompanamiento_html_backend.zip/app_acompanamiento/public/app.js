const state={user:null,page:"home",selectedDate:new Date(),role:null,journal:"",events:[],payments:[],notes:[],youngPeople:[
{id:"y1",name:"Lucía",email:"lucia@demo.local",initial:"L",journal:"Hoy he organizado mis papeles y he ido a clase.",events:2,payments:3},
{id:"y2",name:"Juan",email:"juan@demo.local",initial:"J",journal:"",events:1,payments:2},
{id:"y3",name:"Marta",email:"marta@demo.local",initial:"M",journal:"",events:4,payments:1},
{id:"y4",name:"Pablo",email:"pablo@demo.local",initial:"P",journal:"",events:2,payments:4}
]};

const $=s=>document.querySelector(s);
const today=()=>new Date();
const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
function api(path,opts={}){return fetch(path,{headers:{"Content-Type":"application/json"},...opts}).then(async r=>{let d={};try{d=await r.json()}catch{}if(!r.ok)throw new Error(d.error||"Error");return d})}
function setTitle(t){$("#pageTitle").textContent=t}
function render(){
  $("#login").classList.toggle("hidden",!!state.user);
  $("#main").classList.toggle("hidden",!state.user);
  if(!state.user)return;
  document.querySelectorAll(".bottom-nav button").forEach(b=>b.classList.toggle("active",b.dataset.page===state.page));
  const pages={home:home,diary:diary,calendar:calendar,money:money,more:more};
  pages[state.page]();
}
function home(){
 setTitle("Inicio");
 const name=state.user.name||"";
 $("#content").innerHTML=`<div class="page"><div class="welcome"><div class="muted">Hola,</div><h3>${esc(name)} 🌿</h3><p class="muted">¿Qué necesitas hacer hoy?</p></div>
 <div class="grid">
 <button class="card tile pastel-l" onclick="state.page='diary';render()"><span class="icon">📖</span><strong>Mi diario</strong><small>Escribe cómo ha sido tu día</small></button>
 <button class="card tile pastel-b" onclick="state.page='calendar';render()"><span class="icon">📅</span><strong>Calendario</strong><small>Citas, estudios y trabajo</small></button>
 <button class="card tile pastel-g" onclick="state.page='money';render()"><span class="icon">€</span><strong>Mis pagos</strong><small>Vivienda y gastos</small></button>
 <button class="card tile pastel-p" onclick="state.page='more';render()"><span class="icon">📄</span><strong>Documentos</strong><small>Facturas y justificantes</small></button>
 </div>
 <div class="section-title"><h3>Avisos</h3></div>
 <div class="card"><b>Tu equipo te acompaña</b><p class="muted">Puedes escribir a tus educadores sin utilizar sus números personales.</p></div>
 <div class="section-title"><h3>Emergencia</h3></div>
 <div class="emergency card"><p>Si necesitas ayuda, elige el nivel que corresponda.</p><button class="mild" onclick="emergency('leve')">Necesito hablar con alguien</button><button class="medium" onclick="emergency('importante')">Necesito ayuda pronto</button><button class="grave" onclick="emergency('grave')">🚨 EMERGENCIA GRAVE</button></div>
 </div>`;
}
async function diary(){
 setTitle("Mi diario");
 let value=state.journal;
 if(!value&&state.role==="joven"){try{const d=await api("/api/diary");value=d.entry?.content||""}catch{}}
 $("#content").innerHTML=`<div class="page"><div class="journal"><div class="date">${today().toLocaleDateString("es-ES",{weekday:"long",day:"numeric",month:"long",year:"numeric"})} · ${today().toLocaleTimeString("es-ES",{hour:"2-digit",minute:"2-digit"})}</div><textarea id="journalText" placeholder="Querido diario...">${esc(value)}</textarea></div><button class="primary" style="width:100%;margin-top:12px" onclick="saveDiary()">Guardar entrada</button></div>`;
}
async function saveDiary(){const content=$("#journalText").value;try{await api("/api/diary",{method:"POST",body:JSON.stringify({content})});state.journal=content;alert("Entrada guardada.");}catch(e){alert(e.message)}}
function calendar(){
 setTitle("Calendario");
 const d=state.selectedDate, y=d.getFullYear(),m=d.getMonth(),first=new Date(y,m,1),days=new Date(y,m+1,0).getDate(),offset=(first.getDay()+6)%7;
 let cells="";
 for(let i=0;i<offset;i++)cells+=`<div class="day muted"></div>`;
 for(let n=1;n<=days;n++){let has=(n===new Date().getDate()&&m===new Date().getMonth()&&y===new Date().getFullYear());cells+=`<button class="day ${has?'today':''}" onclick="showDay(${n})">${n}<div class="dots">${(n%4===0)?'<i class="dot blue"></i>':''}${(n%5===0)?'<i class="dot purple"></i>':''}${(n%7===0)?'<i class="dot green"></i>':''}</div></button>`}
 $("#content").innerHTML=`<div class="page"><div class="card"><div class="calendar-head"><button onclick="changeMonth(-1)">‹</button><h3 style="margin:0;font:700 21px Georgia">${d.toLocaleDateString("es-ES",{month:"long",year:"numeric"})}</h3><button onclick="changeMonth(1)">›</button></div><div class="week">${["L","M","X","J","V","S","D"].map(x=>`<div>${x}</div>`).join("")}</div><div class="month-grid">${cells}</div></div><div class="section-title"><h3>Próximas actividades</h3><button class="small-btn" onclick="newEvent()">+ Añadir</button></div><div class="event"><strong>Ejemplo · Cita médica</strong><small>4 octubre · 10:30 · Salud 🔵</small></div><div class="event"><strong>Ejemplo · Administración</strong><small>7 octubre · 12:00 · Documentación 🟣</small></div></div>`;
}
function changeMonth(n){state.selectedDate=new Date(state.selectedDate.getFullYear(),state.selectedDate.getMonth()+n,1);render()}
function showDay(n){const d=new Date(state.selectedDate.getFullYear(),state.selectedDate.getMonth(),n);$("#modalBody").innerHTML=`<h3 style="font:700 23px Georgia">Actividades del ${d.toLocaleDateString("es-ES",{day:"numeric",month:"long"})}</h3><p class="muted">Puedes crear una cita, actividad o recordatorio.</p><div class="modal-actions"><button class="primary" onclick="newEvent()">Nueva actividad</button><button onclick="closeModal()">Cerrar</button></div>`;$("#modal").showModal()}
function newEvent(){const b=$("#modalBody");b.innerHTML=`<h3 style="font:700 23px Georgia">Nueva actividad</h3><label>Título<input id="evTitle" placeholder="Ej. Dentista"></label><br><label>Hora<input id="evTime" type="time"></label><br><label>Lugar<input id="evPlace" placeholder="Lugar"></label><br><label>Categoría<select id="evCat"><option>Salud</option><option>Educación</option><option>Trabajo</option><option>Administración</option><option>Ocio</option><option>Documentación</option></select></label><div class="modal-actions"><button class="primary" onclick="saveEvent()">Guardar</button><button onclick="closeModal()">Cancelar</button></div>`;$("#modal").showModal()}
function saveEvent(){alert("Actividad guardada en el prototipo.");closeModal();render()}
function money(){setTitle("Mis pagos");$("#content").innerHTML=`<div class="page"><div class="card"><div class="between"><div><div class="muted">Total registrado este mes</div><div class="money">460,50 €</div></div><span class="status">Al día</span></div></div><div class="section-title"><h3>Gastos</h3></div>${[["🏠","Vivienda","250,00 €"],["💡","Luz","42,30 €"],["💧","Agua","18,20 €"],["🔥","Gas","—"],["🍎","Alimentación","150,00 €"]].map(x=>`<div class="card event"><div class="between"><span>${x[0]} <b>${x[1]}</b></span><b>${x[2]}</b></div></div>`).join("")}<div class="section-title"><h3>Documentación</h3></div><div class="card"><b>📸 Escanear factura</b><p class="muted">En la versión conectada se subirá al almacenamiento seguro y quedará pendiente de revisión.</p><button class="small-btn" onclick="uploadDemo()">Seleccionar archivo</button></div></div>`}
function uploadDemo(){alert("El prototipo abre aquí el flujo de subida. El backend ya incluye una ruta preparada para documentos.")}
function more(){setTitle("Más");if(state.role!=="joven"){adminPanel();return}$("#content").innerHTML=`<div class="page"><div class="card"><div class="row"><div class="avatar">${esc(state.user.name?.[0]||"A")}</div><div><b>${esc(state.user.name)}</b><div class="muted">${esc(state.user.email)}</div></div></div></div><div class="section-title"><h3>Mi equipo</h3></div><div class="card"><b>Educadores del centro</b><p class="muted">Contacto dentro de la app, sin compartir teléfonos personales.</p><button class="small-btn" onclick="alert('Mensaje enviado al equipo.')">Escribir al equipo</button></div><div class="section-title"><h3>Configuración</h3></div><div class="card"><button class="small-btn" onclick="logout()">Cerrar sesión</button></div></div>`}
async function adminPanel(){setTitle(state.role==="admin"?"Administración":"Mi equipo");$("#content").innerHTML=`<div class="page"><div class="card pastel-b"><b>${state.role==="admin"?"Panel de administración":"Panel profesional"}</b><p>Acceso protegido por rol. Los jóvenes solo pueden consultar su propio perfil.</p></div><div class="section-title"><h3>Jóvenes</h3></div>${state.youngPeople.map(y=>`<div class="young-card"><div><b>${esc(y.name)}</b><div class="muted">${esc(y.email)}</div></div><button onclick="viewYoung('${y.id}')">Abrir</button></div>`).join("")}<div class="section-title"><h3>Emergencias</h3></div><div class="card"><b>Sin emergencias activas</b><p class="muted">Las alertas graves deben generar una notificación prioritaria en la versión móvil.</p></div><div class="section-title"><h3>Cuenta</h3></div><button class="primary" style="width:100%" onclick="logout()">Cerrar sesión</button></div>`}
function viewYoung(id){const y=state.youngPeople.find(x=>x.id===id);$("#modalBody").innerHTML=`<h3 style="font:700 23px Georgia">${esc(y.name)}</h3><p class="muted">${esc(y.email)}</p><div class="card"><b>📖 Última entrada del diario</b><p>${esc(y.journal||"Sin entrada todavía.")}</p></div><div class="card"><b>📅 Actividades</b><p>${y.events} registradas</p></div><div class="card"><b>💶 Pagos</b><p>${y.payments} registros</p></div><div class="card"><b>📝 Nota del educador</b><textarea id="note" placeholder="Escribe una nota que aparecerá al joven"></textarea></div><div class="modal-actions"><button class="primary" onclick="saveNote('${y.id}')">Enviar nota</button><button onclick="closeModal()">Cerrar</button></div>`;$("#modal").showModal()}
function saveNote(id){alert("Nota enviada al perfil del joven.");closeModal()}
function emergency(level){if(!confirm(`¿Confirmas una alerta de nivel ${level.toUpperCase()}?`))return;api("/api/emergency",{method:"POST",body:JSON.stringify({level})}).catch(()=>{});alert(`Aviso de emergencia (${level}) enviado al equipo.`)}
function closeModal(){$("#modal").close()}
async function login(email,password){try{const d=await api("/api/auth/login",{method:"POST",body:JSON.stringify({email,password})});state.user=d.user;state.role=d.user.role;render()}catch(e){alert(e.message)}}
function logout(){api("/api/auth/logout",{method:"POST"}).catch(()=>{});state.user=null;state.role=null;render()}
$("#loginForm").addEventListener("submit",e=>{e.preventDefault();login($("#email").value,$("#password").value)});
$("#googleBtn").addEventListener("click",()=>alert("Google OAuth queda preparado en el backend; para activarlo hay que añadir las credenciales OAuth del proyecto."));
document.querySelectorAll(".bottom-nav button").forEach(b=>b.addEventListener("click",()=>{state.page=b.dataset.page;render()}));
$("#profileBtn").addEventListener("click",()=>{state.page="more";render()});
(async()=>{try{const d=await api("/api/auth/me");if(d.user){state.user=d.user;state.role=d.user.role}}catch{}render()})();
